package com.mycompany.a1;
import com.codename1.ui.Form;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;


/**
 * Game holds the main logic for user commands and represents the GUI for the user.
 * 
 * @author Eric Brown
 *
 */
public class Game extends Form {
	private GameWorld gw;
	private boolean userAttemptingToQuit = false;
	
	/**
	 * Constructor for Game. Creates a game world, initializes it, and then starts a game.
	 */
	public Game() {
		gw  = new GameWorld(); 
		gw.init(); 
		play(); 
	}
	
	/**
	 * Loops infinitely and listens for user commands to alter the game state.
	 */
	private void play() {
		Label myLabel = new Label("Enter a Command:");
		this.addComponent(myLabel);
		final TextField myTextField = new TextField();
		this.addComponent(myTextField);
		this.show();
		
		myTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				String sCommand = myTextField.getText().toString();
				myTextField.clear();
				
				System.out.println("\nEntered: " + sCommand);
				if (sCommand.length() == 0) {  // User entered nothing.
					return;
				}
				
				// Check for user inputs.
				char command = sCommand.charAt(0);
				switch (command) {
					case 'x':  // User attempts to exit the program.
						System.out.println("Are you sure you want to exit? (y/n)");
						userAttemptingToQuit = true;  // Set flag for user confirmation.
						break;
					case 'y':  // User confirmed the exit.
						if (userAttemptingToQuit) {
							System.exit(0);
						}
						break;
					case 'n':  // User denied the exit.
						if (userAttemptingToQuit) {
							System.out.println("Canceled the attempt to quit.");
							userAttemptingToQuit = false;
						}
						break;
					case 'a':  // Accelerate the player.
						System.out.println("Accelerating the player...");
						gw.acceleratePlayerRobot();
						break;
					case 'b':  // Decelerate the player (brake).
						System.out.println("Decelerating the player...");
						gw.deceleratePlayerRobot();
						break;
					case 'l':  // Steer player left (negative compass direction).
						System.out.println("Steering player left...");
						gw.turnPlayerRobotLeft();
						break;
					case 'r':  // Steer player right (positive compass direction).
						System.out.println("Steering player right...");
						gw.turnPlayerRobotRight();
						break;
					case 'c':  // Simulate player collided with another robot.
						System.out.println("Simulating robot collision...");
						gw.collidePlayerRobotWithRobot();
						break;
					case '1':  // Simulate player collided with base number 1-9.
					case '2':
					case '3':
					case '4':
					case '5':
					case '6':
					case '7':
					case '8':
					case '9':
						int baseNumber = command - '0';
						System.out.println("Simulating base collision with base #" + baseNumber + "...");
						gw.collidePlayerRobotWithBase(baseNumber);
						break;
					case 'e':  // Simulate player collided with energy station.
						System.out.println("Simulating energy station collision...");
						gw.collidePlayerRobotWithEnergyStation();
						break;
					case 'g':  // Simulate player collided with drone.
						System.out.println("Simulating drone collision...");
						gw.collidePlayerRobotWithDrone();
						break;
					case 't':  // Tick the game clock (increment in-game time).
						System.out.println("Incrementing game world...");
						gw.tick();
						break;
					case 'd':  // Display current game state.
						gw.printGameState();
						break;
					case 'm':  // Display world map.
						String map = gw.toString();
						System.out.println(map);
						break;
					default:  // User entered an invalid command.
						System.out.println("Unknown command: " + command);
					}
				
				// If the user enters an unknown command or anything other than 'y', the quit is canceled.
				if (userAttemptingToQuit) {
					System.out.println("Canceled the attempt to quit.");
					userAttemptingToQuit = false;
				}
				}  // actionPerformed
			}  // new ActionListener()
		);  // addActionListener
	}  // play
}
