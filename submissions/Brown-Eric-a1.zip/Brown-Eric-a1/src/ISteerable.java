package com.mycompany.a1;


/**
 * ISteerable is an interface that movable objects can implement which allows clients to change their
 * heading by steering the object in small increments either right or left.
 * 
 * @author Eric Brown
 *
 */
public interface ISteerable {
	public abstract void steerRight();
	public abstract void steerLeft();
}
