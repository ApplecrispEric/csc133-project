package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.TextArea;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;


/**
 * This class represents command objects that have to do with controlling the player robot (movement and collisions).
 * 
 * @author Eric Brown
 */
public class PlayerRobotCommand extends Command {
	private static TextField baseNumberTextField;
	private GameWorld gw;
	
	/**
	 * Constructor for PlayerRobotCommand.
	 * 
	 * @param command			name of the command
	 * @param gw				the game world that the command acts upon
	 */
	public PlayerRobotCommand(String command, GameWorld gw) {
		super(command);
		this.gw = gw;
	}
	
	/**
	 * Determines the appropriate method call depending upon the name of the command that was invoked.
	 */
	@Override
	public void actionPerformed(ActionEvent event) {
		switch (this.getCommandName()) {
		case "Accelerate":  // Accelerate the player.
			System.out.println("Accelerating the player...");
			gw.acceleratePlayerRobot();
			break;
		case "Brake":  // Decelerate the player (brake).
			System.out.println("Decelerating the player...");
			gw.deceleratePlayerRobot();
			break;
		case "Left":  // Steer player left (negative compass direction).
			System.out.println("Steering player left...");
			gw.turnPlayerRobotLeft();
			break;
		case "Right":  // Steer player right (positive compass direction).
			System.out.println("Steering player right...");
			gw.turnPlayerRobotRight();
			break;
		case "Collide with NPR": // Collide the player with a NPR.
			System.out.println("Simulating robot collision...");
			gw.collidePlayerRobotWithRobot();
			break;
		case "Collide with Base":  // Collide the player with the base supplied to the dialog input.
			System.out.println("Simulating base collision with next base...");
			baseNumberTextField = new TextField(null, "Base", 1, TextArea.NUMERIC);  // Must create a new text field every time.
			Dialog.show("Enter Base Number", baseNumberTextField, new PlayerRobotCommand("Submit", this.gw));
			break;
		case "Collide with Energy Station":  // Collide player with the last spawned energy station.
			System.out.println("Simulating energy station collision...");
			gw.collidePlayerRobotWithEnergyStation();
			break;
		case "Collide with Drone":  // Collide the player with a drone.
			System.out.println("Simulating drone collision...");
			gw.collidePlayerRobotWithDrone();
			break;
		case "Submit":  // Used for submitting the base number when colliding a player with a base.
			try {
				String text = baseNumberTextField.getText();
				int base = Integer.parseInt(text);
				gw.collidePlayerRobotWithBase(base);
			}
			catch (Exception e) {
				System.out.println("Invalid base number entered!");
			}
			break;
	}
	}
}
