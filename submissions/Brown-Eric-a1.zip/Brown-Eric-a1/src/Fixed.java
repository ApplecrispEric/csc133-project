package com.mycompany.a1;


/**
 * Fixed represents game objects whose location cannot be changed after they have been instantiated.
 * 
 * @author Eric Brown
 */
public abstract class Fixed extends GameObject {
	/**
	 * Base constructor for fixed objects.
	 * @param size				size of the object
	 * @param color				color of the object
	 * @param locationX			permanent x coordinate of the object
	 * @param locationY			permanent y coordinate of the object
	 */
	public Fixed(int size, int color, float locationX, float locationY) {
		super(size, color, locationX, locationY);
	}
	
	/**
	 * Overridden to prevent changes to the objects location.
	 */
	@Override
	public void setLocationX(float x) {}  // Do nothing: cannot change Fixed object's position.
	
	/**
	 * Overridden to prevent changes to the objects location.
	 */
	@Override
	public void setLocationY(float y) {}  // Do nothing: cannot change Fixed object's position.
	
	/**
	 * @return			a string representing the objects current state
	 */
	@Override
	public String toString() {
		String state = super.toString();
		return "[Fixed] " + state;
	}
}