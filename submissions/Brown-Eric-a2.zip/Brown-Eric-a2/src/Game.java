package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Button;
import com.codename1.ui.CheckBox;
import com.codename1.ui.Command;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.plaf.Style;
import com.codename1.ui.Toolbar;


/**
 * Game holds the main logic for user commands and represents the GUI for the user.
 * 
 * @author Eric Brown
 *
 */
public class Game extends Form {
	private GameWorld gw;
	
	/**
	 * Constructor for Game. Creates a game world, initializes it, and then starts a game.
	 */
	public Game() {
		this.setLayout(new BorderLayout());
		gw  = new GameWorld();		

		// Create a universal style for all the buttons used in the application.
		Style buttonStyle = new Style();
		int buttonStylePadding = 35;
		int buttonStyleBorderThickness = 3;
		int buttonStyleBgColor = ColorUtil.BLUE;
		int buttonStyleFgColor = ColorUtil.WHITE;
		
		buttonStyle.setPadding(Component.TOP, buttonStylePadding);
		buttonStyle.setPadding(Component.BOTTOM, buttonStylePadding);
		buttonStyle.setPadding(Component.LEFT, buttonStylePadding);
		buttonStyle.setPadding(Component.RIGHT, buttonStylePadding);
		buttonStyle.setBorder(Border.createLineBorder(buttonStyleBorderThickness, ColorUtil.BLACK));
		buttonStyle.setBgColor(buttonStyleBgColor);
		buttonStyle.setFgColor(buttonStyleFgColor);
		buttonStyle.setAlignment(CENTER);
		
		// Create the layout and components on the screen.
		Container leftContainer = new Container(BoxLayout.yCenter());
		Container rightContainer = new Container(BoxLayout.yCenter());
		Container bottomContainer = new Container(BoxLayout.xCenter());
		
		// Create all the command objects once (Singleton pattern).
		Command accelerate = new PlayerRobotCommand("Accelerate", gw);
		Command brake = new PlayerRobotCommand("Brake", gw);
		Command turnLeft = new PlayerRobotCommand("Left", gw);
		Command turnRight = new PlayerRobotCommand("Right", gw);
		Command collideNPR = new PlayerRobotCommand("Collide with NPR", gw);
		Command collideDrone = new PlayerRobotCommand("Collide with Drone", gw);
		Command collideStation = new PlayerRobotCommand("Collide with Energy Station", gw);
		Command collideBase = new PlayerRobotCommand("Collide with Base", gw);
		
		Command tick = new GameCommand("Tick", gw);
		Command help = new GameCommand("Help", gw);
		Command about = new GameCommand("About", gw);
		Command exit = new GameCommand("Exit", gw);
		Command sound = new GameCommand("Enable Sound", gw);
		Command changeStrategies = new GameCommand("Change Strategies", gw);
		
		// Add the buttons to the side containers.
		leftContainer.add(new Button(accelerate));
		leftContainer.add(new Button(turnLeft));
		leftContainer.add(new Button(changeStrategies));
		bottomContainer.add(new Button(collideNPR));
		bottomContainer.add(new Button(collideBase));
		bottomContainer.add(new Button(collideStation));
		bottomContainer.add(new Button(collideDrone));
		bottomContainer.add(new Button(tick));
		rightContainer.add(new Button(brake));
		rightContainer.add(new Button(turnRight));
		
		ScoreView score = new ScoreView();

		// Add the containers to the screen.
		this.add(BorderLayout.NORTH, score);
		this.add(BorderLayout.WEST, leftContainer);
		this.add(BorderLayout.EAST, rightContainer);
		this.add(BorderLayout.SOUTH, bottomContainer);
		
		// Create the map.
		MapView map = new MapView();
		map.getAllStyles().setBorder(Border.createLineBorder(10, ColorUtil.rgb(255, 0, 0)));
		this.add(BorderLayout.CENTER, map);
		
		// Add the keyboard commands.
		this.addKeyListener('a', accelerate);
		this.addKeyListener('b', brake);
		this.addKeyListener('l', turnLeft);
		this.addKeyListener('r', turnRight);
		this.addKeyListener('e', collideStation);
		this.addKeyListener('g', collideDrone);
		this.addKeyListener('b', brake);
		this.addKeyListener('t', tick);
		
		// Create the side tool bar for the application.
		Toolbar toolbar = new Toolbar();
		this.setToolbar(toolbar);
		toolbar.setTitle("Robo-track Game");
		
		// Add sound toggle.
		CheckBox soundCheckBox = new CheckBox();
		soundCheckBox.setCommand(sound);
		soundCheckBox.setSelected(gw.getSoundEnabled());
		toolbar.addComponentToSideMenu(soundCheckBox);
		
		// Add buttons for user information and quitting.
		toolbar.addComponentToSideMenu(new Button(about));
		toolbar.addComponentToSideMenu(new Button(exit));
		toolbar.addComponentToSideMenu(new Button(accelerate));
		toolbar.addCommandToRightBar(help);  // Right side of toolbar.
		
		// Style the containers and their button components.
		for (Container c : new Container[] {leftContainer, rightContainer, bottomContainer, score}) {
			c.getAllStyles().setBorder(Border.createLineBorder(3, ColorUtil.BLACK));
			this.setContainerButtonsToStyle(c, buttonStyle);
		}
		
		// Set the dimensions of the world after the map size has been calculated.
		this.show();
		gw.setWidth(map.getWidth());
		gw.setHeight(map.getHeight());
		
		gw.addObserver(score);
		gw.addObserver(map);
		
		gw.init();  // Initialize the GameWorld at the end to notify all components (observers).
	}
	
	/**
	 * Sets all of the button GUI elements within a container to the same style for uniformity.
	 * 
	 * @param container					the container's whose buttons should be altered
	 * @param style						the style to style the buttons after
	 */
	private void setContainerButtonsToStyle(Container container, Style style) {
		for (Component c : container) {
			if (c instanceof Button) {
				((Button)c).getAllStyles().merge(style);
			}
		}
	}
}
