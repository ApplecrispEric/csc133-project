package com.mycompany.a1;

/**
 * GameObject is the abstract class that represents an in-game entity which are
 * physical objects that have some impact on the actual game play.
 * 
 * @author Eric Brown
 *
 */
public abstract class GameObject {
	private int size;
	private int color;
	private float locationX;
	private float locationY;
	
	
	/**
	 * Constructor for GameObject.
	 * 
	 * @param size			size of object
	 * @param color			color of object
	 * @param locationX		x coordinate of object's location
	 * @param locationY		y coordinate of object's location
	 */
	public GameObject(int size, int color, float locationX, float locationY) {
		this.size = size;
		this.color = color;
		this.locationX = locationX;
		this.locationY = locationY;
	}
	
	/**
	 * Getter for size.
	 * 
	 * @return		current size of the object
	 */
	public int getSize() {
		return this.size;
	}
	
	/**
	 * Setter for locationX.
	 * 
	 * @param 		new X coordinate for the object in game space
	 */
	public void setLocationX(float x) {
		this.locationX = x;
	}
	
	/**
	 * Setter for locationY.
	 * 
	 * @param y		new Y coordinate for the object in game space
	 */
	public void setLocationY(float y) {
		this.locationY = y;
	}
	
	/**
	 * Getter for locationX.
	 * 
	 * @return		current X coordinate of the object
	 */
	public float getLocationX() {
		return this.locationX;
	}
	
	/**
	 * Getter for locationY.
	 * 
	 * @return		current Y coordinate of the object
	 */
	public float getLocationY() {
		return this.locationY;
	}
	
	
	/**
	 * Getter for color.
	 * 
	 * @return		current object color
	 */
	public int getColor() {
		return this.color;
	}
	
	/**
	 * Setter for color.
	 * 
	 * @param color		new color to set object to
	 */
	public void setColor(int color) {
		this.color = color;
	}
	
	/**
	 * @return			a string representing the object's current state
	 */
	public String toString() {
		return "[GameObject] Location: (" + this.locationX + ", " + this.locationY + ") "
				+ "Color: " + this.color + ", Size: " + this.size;
	}
}
