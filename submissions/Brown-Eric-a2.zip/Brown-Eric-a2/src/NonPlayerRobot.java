package com.mycompany.a2;
import com.codename1.util.MathUtil;


/**
 * NonPlayerRobots represent opposing robots that compete against the player to either
 * damage the player or beat them by reaching the last base first.
 * 
 * @author Eric Brown
 */
public class NonPlayerRobot extends Robot {
	private static final int MAX_DAMAGE_AMOUNT = 250;
	private IStrategy strategy;
	
	/**
	 * Constructor for the NPR.
	 * 
	 * @param size				size of the robot
	 * @param color				color of the robot	
	 * @param locationX			starting x location of the robot
	 * @param locationY			starting y location of the robot
	 * @param heading			initial heading
	 * @param strategy			initial strategy
	 */
	public NonPlayerRobot(int size, int color, float locationX, 
			float locationY, int heading, IStrategy strategy) {
		super(size, color, locationX, locationY, Robot.INTIAL_MAX_SPEED, heading, MAX_DAMAGE_AMOUNT);
		this.strategy = strategy;
	}
	
	/**
	 * Moves the robot by one tick of in-game time.
	 */
	@Override
	public void move() {
		this.invokeStrategy();
		super.move();
		this.chargeRobot(this.getEnergyConsumptionRate());  // NPR's should never run out of energy.
	}
	
	/**
	 * Alter the robot's state according to its current strategy.
	 */
	private void invokeStrategy() {
		this.strategy.invoke();
	}
	
	/**
	 * Getter for the robot's strategy.
	 * 
	 * @return			the current strategy
	 */
	public IStrategy getStrategy() {
		return this.strategy;
	}
	
	/**
	 * Setter for the robot's strategy.
	 * 
	 * @param strategy		the new strategy
	 */
	public void setStrategy(IStrategy strategy) {
		this.strategy = strategy;
	}
	
	/**
	 * Alters the robot's steering direction based on an intended location.
	 * 
	 * @param locationX					x coordinate of intended location
	 * @param locationY					y coordinate of intended location
	 */
	public void steerTowardsIntendedLocation(float locationX, float locationY) {
		float deltaX = locationX - this.getLocationX();
		float deltaY = locationY - this.getLocationY();
		
		double headingInRadians = 360 - MathUtil.atan(deltaX / deltaY);
		int intendedHeadingInDegrees = (int) Math.toDegrees(headingInRadians);
		
		// Hard steering, not very effective for the robots, but is simple.
		if (this.getHeading() < intendedHeadingInDegrees) {
			for (int i = 0; i < MAX_STEER_VALUE / MAX_STEER_INCREMENT; i++) {
				this.steerRight();
			}
		}
		else if (this.getHeading() > intendedHeadingInDegrees){
			for (int i = 0; i < MAX_STEER_VALUE / MAX_STEER_INCREMENT; i++) {
				this.steerLeft();
			}
		}
	}
	
	/**
	 * @return			string representation of the NPR
	 */
	@Override
	public String toString() {
		String state = super.toString();
		return "[NPR] " + state + ", Strategy: " + strategy.toString(); 
	}
}