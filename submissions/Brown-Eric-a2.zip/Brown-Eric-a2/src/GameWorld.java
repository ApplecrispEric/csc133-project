package com.mycompany.a2;

import java.util.Random;
import com.codename1.charts.util.ColorUtil;
import java.util.Observable;


/**
 * GameWorld holds the collection of GameObjects currently in play and other various
 * state information that represents the current game in progress.
 * 
 * @author Eric Brown
 */
public class GameWorld extends Observable {
	private static final int INITIAL_LIVES = 3;
	private static final int SPEED_INCREMENT = 10;
	private static final int TOTAL_BASE_COUNT = 9;

	
	private int width;
	private int height;
	private boolean soundEnabled = true;
	private int lives = INITIAL_LIVES;
	private int clock = 0;  // Tracks number of ticks of in-game time have occurred.
	private GameObjectCollection objectCollection = new GameObjectCollection();
	
	
	private Robot player;
	private EnergyStation debugEnergyStation;
	
	public void setWidth(int width) {
		this.width = width;
	}
	
	public void setHeight(int height) {
		this.height = height;
	}
	
	/**
	 * Initializes the game state by creating the GameObjects.
	 */
	public void init() {
		this.player = Robot.resetPlayerRobot();
		this.objectCollection.add(player);
		
		Random generator = new Random(System.currentTimeMillis());

		// Instantiate the bases.
		for (int i = 1; i < TOTAL_BASE_COUNT + 1; i++) {
			int x = generator.nextInt(width);
			int y = generator.nextInt(height);
			this.objectCollection.add(new Base(ColorUtil.BLACK, x, y, i));
		}
		
		// Make sure the robots are some distance away from the first base and player.
		float robotX = getBaseLocationX(1) + 60;
		float robotY = getBaseLocationY(1) + 60;
		
		// Create a robot that attacks the player.
		NonPlayerRobot robot = new NonPlayerRobot(10, ColorUtil.YELLOW, robotX, robotY, 0, null);
		robot.setStrategy(new AttackStrategy(robot));
		this.objectCollection.add(robot);
		
		// Create a robot that races the player.
		robot = new NonPlayerRobot(10, ColorUtil.YELLOW, robotX, robotY, 0, null);
		robot.setStrategy(new RaceStrategy(robot, this));
		this.objectCollection.add(robot);
		
		// Create a third robot as per specifications.
		robot = new NonPlayerRobot(10, ColorUtil.YELLOW, robotX, robotY, 0, null);
		robot.setStrategy(new RaceStrategy(robot, this));
		this.objectCollection.add(robot);
		
		// EnergyStations are spawned as needed for debugging purposes.
		this.debugEnergyStation = new EnergyStation(100, 0, 0);
		this.objectCollection.add(debugEnergyStation);
		
		// Add a single drone for debug purposes.
		this.objectCollection.add(new Drone(50, ColorUtil.GRAY, 0, 0, 100, 45, this.width, this.height));
		
		// Initialize the text displayed by the GUI.
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * Increments the internal game state by a single time unit.
	 */
	public void tick() {
		this.clock++;
		IIterator iterator = this.objectCollection.getIterator();
		
		// Iterate over the GameObjects using iterator pattern.
		while (iterator.hasNext()) {
			GameObject object = iterator.getNext();
			if (object instanceof Movable) {
				((Movable) object).move();
				
				// Check to see if an NPR won the game.
				if (object instanceof NonPlayerRobot) {
					if (((NonPlayerRobot) object).getLastBaseReached() == TOTAL_BASE_COUNT) {
						System.out.println("Game over, a non-player robot wins!");
						System.exit(0);
					}
				}
			}
		}
		
		if (Robot.getPlayerRobot().isDead()) {
			System.out.println("Robot is unable to move, starting next life...\n");
			this.startNextLife();
		}
		
		if (player.getLastBaseReached() == TOTAL_BASE_COUNT) {
			System.out.println("Game over, you win! Total time: " + this.clock);
		}
		
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * Increases the player robot's speed by a small amount.
	 */
	public void acceleratePlayerRobot() {
		player.setSpeed(player.getSpeed() + SPEED_INCREMENT);
		System.out.println("Player speed is now " + player.getSpeed() + ".\n");
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * Decreases the player robot's speed by a small amount.
	 */
	public void deceleratePlayerRobot() {
		player.setSpeed(player.getSpeed() - SPEED_INCREMENT);
		System.out.println("Player speed is now " + player.getSpeed() + ".\n");
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * Turns the robot player left (counter-clockwise) by a small amount.
	 */
	public void turnPlayerRobotLeft() {
		player.steerLeft();
		System.out.println("New steering direction is " + player.getSteeringDirection() + ".\n");
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * Turns the robot player right (clockwise) by a small amount.
	 */
	public void turnPlayerRobotRight() {
		player.steerRight();
		System.out.println("New steering direction is " + player.getSteeringDirection() + ".\n");
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * Simulates a collision between the player and another robot, damaging the player.
	 */
	public void collidePlayerRobotWithRobot() {
		IIterator iterator = objectCollection.getIterator();
		boolean collided = false;
		
		while (iterator.hasNext()) {
			GameObject object = iterator.getNext();
			
			if (object instanceof NonPlayerRobot) {
				NonPlayerRobot robot = (NonPlayerRobot) object;
				
				int damageAmount = Drone.DAMAGE_TO_OTHER_ENTITIES;
				player.damage(damageAmount);  // Damage the player.
				robot.damage(damageAmount);  // Damage the other robot.
				collided = true;
				break;
			}
		}
		
		if (!collided) {
			System.out.println("No robot to collide with! No damage was done.");
		}
		
		System.out.println("Player damage: " + player.getDamageLevel() + ".\n");
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * Simulates a collision with the player robot and a base.
	 * 
	 * @param baseNumber		the corresponding base's sequence number to collide the player with
	 */
	public void collidePlayerRobotWithBase(int baseNumber) {
		if (player.getLastBaseReached() + 1 != baseNumber) {
			System.out.println("Player attempted to collide with the wrong base (out of order).\n");
			return;
		}
		
		player.setLastBaseReached(baseNumber);
		System.out.println("Player collided with base " + player.getLastBaseReached() + "\n");
		
		if (player.getLastBaseReached() == TOTAL_BASE_COUNT - 1) {
			System.out.print("Game over, you win! Total time: " + clock);
			System.exit(0);
		}
	}
	
	/**
	 * Simulates a collision between the player robot and an EnergyStation, recharging the player.
	 */
	public void collidePlayerRobotWithEnergyStation() {
		// Recharge player and drain EnergyStation.
		player.chargeRobot(debugEnergyStation.drainEnergy());
		debugEnergyStation.drainEnergy();
		System.out.println("Player energy: " + player.getEnergyLevel() + ".\n");
		
		// Create a new, full EnergyStation.
		Random generator = new Random(System.currentTimeMillis());
		int x = generator.nextInt(width);
		int y = generator.nextInt(height);
		int size = generator.nextInt(50) + 50;
		
		debugEnergyStation = new EnergyStation(size, x, y);
		this.objectCollection.add(debugEnergyStation);
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * Simulates a collision between the player and a drone, damaging the player.
	 */
	public void collidePlayerRobotWithDrone() {
		int damageAmount = Drone.DAMAGE_TO_OTHER_ENTITIES;
		player.damage(damageAmount);
		System.out.println("Player damage: " + player.getDamageLevel() + ".\n");
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * Initializes the game world again for the player's next life and checks for game over.
	 * The game objects are deleted and recreated for a clean slate.
	 */
	public void startNextLife() {
		this.objectCollection.clear();
		this.init();
		this.lives--;
		
		System.out.println("You have " + this.lives + " lives remaining...\n");
		
		if (this.lives == 0) {
			System.out.println("Game over, you failed!");
			System.exit(0);
		}
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * @return		string representation of the all the game objects currently in play.
	 */
	public String toString() {
		String state = "[MAP] Listing the GameObjects in play...";
		IIterator iterator = this.objectCollection.getIterator();
		
		while (iterator.hasNext()) {
			GameObject object = iterator.getNext();
			state += "\n\t" + object.toString();
		}
		return state;
	}
	
	
	/**
	 * Getter for clock.
	 * 
	 * @return			current clock value
	 */
	public int getClock() {
		return this.clock;
	}
	
	/**
	 * Getter for lives.
	 * 
	 * @return			current number of lives left
	 */
	public int getLives() {
		return this.lives;
	}
	
	/**
	 * Setter for soundEnabled.
	 * 
	 * @param enabled			Boolean for whether or not sound should be enabled.
	 */
	public void setSoundEnabled(boolean enabled) {
		this.soundEnabled = enabled;
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * Getter for soundEnabled.
	 * 
	 * @return				whether sound enabled is true or false
	 */
	public boolean getSoundEnabled() {
		return this.soundEnabled;
	}
	
	/**
	 * Getter for last base reached by the player.
	 * 
	 * @return				the last base the player has reached
	 */
	public int getPlayerLastBase() {
		return this.player.getLastBaseReached();
	}
	
	/**
	 * Getter for the player's energy level.
	 * 
	 * @return				current energy level for the player
	 */
	public int getPlayerEnergyLeft() {
		return this.player.getEnergyLevel();
	}
	
	/**
	 * Getter for the player's damage level.
	 * 
	 * @return				current damage level for the player.
	 */
	public int getPlayerDamage() {
		return this.player.getDamageLevel();
	}
	
	/**
	 * Getter for the x coordinate of the specified base.
	 * 
	 * @param base				base number to locate
	 * @return					x coordinate of the specified base, -1 if base number is invalid
	 */
	public float getBaseLocationX(int base) {
		IIterator iterator = this.objectCollection.getIterator();
		
		while (iterator.hasNext()) {
			GameObject object = iterator.getNext();
			
			if (object instanceof Base) {
				Base b = (Base) object;
				if (b.getSequenceNumber() == base)
					return b.getLocationX();
			}
		}
		
		System.out.println("Couldn't find x location for base #" + base);
		return -1; // Returns an invalid location in case base number is invalid.
	}
	
	/**
	 * Getter for the y coordinate of the specified base.
	 * 
	 * @param base				base number to locate
	 * @return					y coordinate of the specified base, -1 if base number is invalid
	 */
	public float getBaseLocationY(int base) {
		IIterator iterator = this.objectCollection.getIterator();
		
		while (iterator.hasNext()) {
			GameObject object = iterator.getNext();
			
			if (object instanceof Base) {
				Base b = (Base) object;
				if (b.getSequenceNumber() == base)
					return b.getLocationY();
			}
		}
		
		System.out.println("Couldn't find y location for base #" + base + "\n");
		return -1; // Returns an invalid location in case base number is invalid.
	}
	
	/**
	 * Changes the strategies of all the NPRs that are currently in play and also increments the last base reached values.
	 */
	public void changeNPRStrategies() {
		IIterator iterator = this.objectCollection.getIterator();
		
		while (iterator.hasNext()) {
			GameObject object = iterator.getNext();
			
			if (object instanceof NonPlayerRobot) {
				NonPlayerRobot robot = (NonPlayerRobot) object;
				
				int nextBase = robot.getLastBaseReached() + 1;
				// Make sure that the NPRs never go past the last base.
				if (nextBase > TOTAL_BASE_COUNT) {
					nextBase = TOTAL_BASE_COUNT;
				}
				
				robot.setLastBaseReached(nextBase); // Increment the last base the robot reached to progress the robot.
				
				// The NPRs switch to race if they were attacking before and vice versa.
				if (robot.getStrategy() instanceof RaceStrategy) {
					robot.setStrategy(new AttackStrategy(robot));
				}
				else {
					robot.setStrategy(new RaceStrategy(robot, this));
				}
			}
		}
		System.out.println("Strategies for each robot have been flipped.\n");
		
		this.setChanged();
		this.notifyObservers();
	}
}
