package com.mycompany.a2;

import java.util.Observer;
import java.util.Observable;
import com.codename1.ui.Container;


/**
 * MapView represents a map of the current game state to be displayed in the center of
 * the screen. It observes the game world to update the map accordingly.
 * 
 * @author Eric Brown
 */
public class MapView extends Container implements Observer {
	
	/**
	 * Updates the map.
	 */
	@Override
	public void update(Observable observable, Object data) {
		GameWorld gw = (GameWorld)observable;
		System.out.println(gw + "\n");  // Show current state to the console.
	}
}
