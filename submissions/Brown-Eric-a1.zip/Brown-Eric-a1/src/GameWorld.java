package com.mycompany.a1;
import java.util.Random;
import java.util.Vector;
import com.codename1.charts.util.ColorUtil;


/**
 * GameWorld holds the collection of GameObjects currently in play and other various
 * state information that represents the current game in progress.
 * 
 * @author Eric Brown
 */
public class GameWorld {
	public static final int WORLD_WIDTH = 1024;
	public static final int WORLD_HEIGHT = 768;
	private static final int INITIAL_LIVES = 3;
	private static final int SPEED_INCREMENT = 10;
	private static final int TOTAL_BASE_COUNT = 10;
	
	private int lives = INITIAL_LIVES;
	private int clock = 0;  // Tracks number of ticks of in-game time have occurred.
	private Vector<GameObject> gameObjects = new Vector<>();
	
	private Robot player;
	private Drone debugDrone;
	private EnergyStation debugEnergyStation;
	
	/**
	 * Initializes the game state by creating the GameObjects.
	 */
	public void init() {
		Random generator = new Random(System.currentTimeMillis());
		int droneColor = ColorUtil.CYAN;
		int robotColor = ColorUtil.BLACK;
		int robotSize = 50;
		
		this.player = new Robot(robotSize, robotColor, 0, 0, 0, 0);
		this.debugDrone = new Drone(generator.nextInt(40) + 10, droneColor, 10, 10, 100, 270, WORLD_WIDTH, WORLD_HEIGHT);
		this.debugEnergyStation = new EnergyStation(100, 100, 100);
		
		this.addGameObject(player);
		this.addGameObject(debugDrone);
		this.addGameObject(debugEnergyStation);
		
		int baseColor = ColorUtil.BLUE;
		
		// Instantiate the bases.
		for (int i = 1; i < TOTAL_BASE_COUNT; i++) {
			int x = generator.nextInt(WORLD_WIDTH);
			int y = generator.nextInt(WORLD_HEIGHT);
			this.addGameObject(new Base(baseColor, x, y, i));
		}
		
		// EnergyStations are spawned as needed for debugging purposes.
	}
	
	/**
	 * Increments the internal game state by a single time unit.
	 */
	public void tick() {
		this.clock++;

		for (GameObject object: gameObjects) {
			if (object instanceof Movable) {
				((Movable) object).move();
			}
		}
		
		if (player.isDead()) {
			System.out.println("Robot is unable to move, starting next life...");
			this.startNextLife();
		}
		
		if (player.getLastBaseReached() == 9) {
			System.out.println("Game over, you win! Total time: " + this.clock);
		}
	}
	
	/**
	 * Increases the player robot's speed by a small amount.
	 */
	public void acceleratePlayerRobot() {
		player.setSpeed(player.getSpeed() + SPEED_INCREMENT);
		System.out.println("Player speed is now " + player.getSpeed() + ".");
	}
	
	/**
	 * Decreases the player robot's speed by a small amount.
	 */
	public void deceleratePlayerRobot() {
		player.setSpeed(player.getSpeed() - SPEED_INCREMENT);
		System.out.println("Player speed is now " + player.getSpeed() + ".");
	}
	
	/**
	 * Turns the robot player left (counter-clockwise) by a small amount.
	 */
	public void turnPlayerRobotLeft() {
		player.steerLeft();
		System.out.println("New steering direction is " + player.getSteeringDirection() + ".");
	}
	
	/**
	 * Turns the robot player right (clockwise) by a small amount.
	 */
	public void turnPlayerRobotRight() {
		player.steerRight();
		System.out.println("New steering direction is " + player.getSteeringDirection() + ".");
	}
	
	/**
	 * Simulates a collision between the player and another robot, damaging the player.
	 */
	public void collidePlayerRobotWithRobot() {
		int damageAmount = Drone.DAMAGE_TO_OTHER_ENTITIES;
		player.damage(damageAmount);
		System.out.println("Player damage: " + player.getDamageLevel());
	}
	
	/**
	 * Simulates a collision with the player robot and a base.
	 * 
	 * @param baseNumber		the corresponding base's sequence number to collide the player with
	 */
	public void collidePlayerRobotWithBase(int baseNumber) {
		if (player.getLastBaseReached() + 1 != baseNumber) {
			System.out.println("Player attempted to collide with the wrong base (out of order).");
			return;
		}
		player.setLastBaseReached(baseNumber);
		
		if (player.getLastBaseReached() == TOTAL_BASE_COUNT - 1) {
			System.out.print("Game over, you win! Total time: " + clock);
			System.exit(0);
		}
	}
	
	/**
	 * Simulates a collision between the player robot and an EnergyStation, recharging the player.
	 */
	public void collidePlayerRobotWithEnergyStation() {
		// Recharge player and drain EnergyStation.
		player.chargeRobot(debugEnergyStation.drainEnergy());
		debugEnergyStation.drainEnergy();
		System.out.println("Player energy: " + player.getEnergyLevel());
		
		// Create a new, full EnergyStation.
		Random generator = new Random(System.currentTimeMillis());
		int x = generator.nextInt(WORLD_WIDTH);
		int y = generator.nextInt(WORLD_HEIGHT);
		int size = generator.nextInt(50) + 50;
		
		debugEnergyStation = new EnergyStation(size, x, y);
		this.addGameObject(debugEnergyStation);
		
	}
	
	/**
	 * Simulates a collision between the player and a drone, damaging the player.
	 */
	public void collidePlayerRobotWithDrone() {
		int damageAmount = Drone.DAMAGE_TO_OTHER_ENTITIES;
		player.damage(damageAmount);
		System.out.println("Player damage: " + player.getDamageLevel());
	}
	
	/**
	 * Initializes the game world again for the player's next life and checks for game over.
	 * The game objects are deleted and recreated for a clean slate.
	 */
	public void startNextLife() {
		this.clearGameObjects();
		this.init();
		this.lives--;
		
		System.out.println("You have " + this.lives + " lives remaining...");
		
		if (this.lives == 0) {
			System.out.println("Game over, you failed!");
			System.exit(0);
		}
	}
	
	/**
	 * @return		string representation of the all the game objects currently in play.
	 */
	public String toString() {
		String state = "[MAP] Listing the GameObjects in play...";
		for (GameObject object : gameObjects) {
			state += "\n\t" + object.toString();
		}
		return state;
	}
	
	/**
	 * Prints the important game information such as user lives and state to the console.
	 */
	public void printGameState() {
		System.out.println("Lives left:" + this.lives
				+ "\nCurrent clock value: " + this.clock + " ticks"
				+ "\nHighest base reached so far: " + this.player.getLastBaseReached()
				+ "\nUser robot's current energy: " + this.player.getEnergyLevel()
				+ "\nUser robot's current damage: " + this.player.getDamageLevel());
	}
	
	/**
	 * Adds a game object to the world.
	 * 
	 * @param object			the object to add to the game world
	 */
	private void addGameObject(GameObject object) {
		this.gameObjects.add(object);
	}
	
	/**
	 * Deletes all the current game objects from play.
	 */
	private void clearGameObjects() {
		this.gameObjects.clear();
	}
}
