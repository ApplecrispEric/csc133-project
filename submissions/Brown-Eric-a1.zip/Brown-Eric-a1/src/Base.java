package com.mycompany.a1;


/**
 * Base represents a physical, immovable GameObject that the player robot uses to recharge its energy level.
 * Bases are indexed by a sequenceNumber which keeps track of the order of bases along the intended
 * path for the player to traverse. The bases must be traversed in increasing order to progress the game.
 * 
 * @author Eric Brown
 *
 */
public class Base extends Fixed {
	private static final int BASE_SIZE = 50;  // Size of all bases.
	private int sequenceNumber;  // Sequence number of the base. Must be traversed in order to progress the game.
	
	/**
	 * Constructor for the Base class.
	 * 
	 * @param color				color of the base
	 * @param locationX			initial x coordinate of the base
	 * @param locationY			initial y coordinate of the base
	 * @param sequenceNumber	sequence number of the base
	 */
	public Base(int color, float locationX, float locationY, int sequenceNumber) {
		super(BASE_SIZE, color, locationX, locationY);
		this.sequenceNumber = sequenceNumber;
	}
	
	/**
	 * Getter for sequenceNumber.
	 * 
	 * @return		sequenceNumber for the base.
	 */
	public int getSequenceNumber() {
		return this.sequenceNumber;
	}
	
	/**
	 * @return		a string representing the base's state
	 */
	public String toString() {
		String state = super.toString();
		return "[Base] " + state + ", Sequence #: " + this.sequenceNumber;
	}
}
